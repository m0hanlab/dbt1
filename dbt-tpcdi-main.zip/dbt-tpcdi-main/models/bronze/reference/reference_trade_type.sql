select *
from {{ source('reference','trade_type') }}
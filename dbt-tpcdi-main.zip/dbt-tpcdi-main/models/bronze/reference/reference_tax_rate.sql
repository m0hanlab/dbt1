select *
from {{ source('reference','tax_rate') }}
select *
from {{ source('reference','status_type') }}
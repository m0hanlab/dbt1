select *
from {{ source('reference','industry') }}
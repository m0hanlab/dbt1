select *
from {{ ref('date') }}
select *
from {{ ref('reference_date') }}